#!/usr/bin/env python3
"""Connection lifecycle: disconnect, client shell management, require_client."""

from __future__ import annotations

import logging
from typing import Any

from comsol_mcp._server import _get_mph
import comsol_mcp._server as _srv


def _timed_call(func, *args, timeout: float = 30.0, error_msg=""):
    """Execute in the daemon queue; waiting is not engine cancellation."""
    try:
        return func(*args)
    except Exception:
        raise


def _disconnect_locked(*, shutdown_server: bool = False) -> None:
    if _srv._client is not None:
        try:
            _timed_call(_srv._client.disconnect, timeout=15.0)
        except Exception as exc:
            if "not connected" not in str(exc).lower():
                _srv._last_error = f"Disconnect failed: {exc}"
        finally:
            _srv._client_connected = False
            _srv._connected_host = ""
            _srv._connected_port = None
            _srv._client = None

    _srv._current_model = None
    _srv._current_model_origin = ""
    _srv._current_model_path = ""
    _srv._mcp_owned_model_tags.clear()

    if shutdown_server and _srv._server is not None and _srv._server_started_by_mcp:
        try:
            _srv._server.stop()
        except Exception as exc:
            _srv._last_error = f"Server stop failed: {exc}"
        finally:
            _srv._server = None
            _srv._server_started_by_mcp = False
    elif shutdown_server:
        _srv._server = None
        _srv._server_started_by_mcp = False


def _ensure_client_shell() -> Any:
    if _srv._client is None:
        if _srv._remote_client_factory is not None:
            _srv._client = _srv._remote_client_factory()
            return _srv._client
        mph = _get_mph()
        if mph is None:
            raise RuntimeError("MPh is not available; cannot create client shell.")
        client_kwargs: dict[str, Any] = {"host": None}
        if _srv.DEFAULT_VERSION:
            client_kwargs["version"] = _srv.DEFAULT_VERSION
        _srv._client = mph.Client(**client_kwargs)
    return _srv._client


def _require_client() -> Any:
    if _srv._client is None or not _srv._client_connected:
        raise RuntimeError("Not connected to a COMSOL Multiphysics Server.")
    return _srv._client
